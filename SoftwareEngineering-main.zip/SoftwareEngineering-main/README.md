CSCI4050 Software Engineering Group Project
-----

Run using 
```bash
node CinemaEBookingSystem/server.js 
node server.js 
```
-----
Some Dependencies:
```bash
npm update
npm install @sendgrid/mail
```
admin--> user: admin0 
	 password: admin123


